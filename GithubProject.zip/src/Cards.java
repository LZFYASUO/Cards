import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public class Cards {
    public static void main(String[] args) {
        /*准备牌*/
        ArrayList<String> list = new ArrayList<String>();
        list.add("大王");
        list.add("小王");
        System.out.println(list);
        String colors[] = {"♣", "♥", "♦", "♠"};
        String numbers[] = {"2", "A", "K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3"};
        Collection<String> c = new ArrayList<String>();
        for (String color : colors) {
            for (String number : numbers) {
                list.add(color + number);
                //System.out.println(c);
                //System.out.println(list);
            }

        }
        /*洗牌*/
        Collections.shuffle(list);
        // System.out.println(list);

        /*发牌*/
        ArrayList<String> player1 = new ArrayList<String>();
        ArrayList<String> player2 = new ArrayList<String>();
        ArrayList<String> player3 = new ArrayList<String>();
        ArrayList<String> remainder = new ArrayList<String>();
        //System.out.println(list.size());
        for (int i = 0; i < list.size(); i++) {
            if (i > 50) {
                remainder.add(list.get(i));
            } else if (i % 3 == 0) {
                player1.add(list.get(i));
            } else if (i % 3 == 1) {
                player2.add(list.get(i));
            } else {
                player3.add(list.get(i));
            }
        }
        System.out.println("赌神" + player1);
        System.out.println("赌圣" + player2);
        System.out.println("赌王" + player3);
        System.out.println("底注" + remainder);

    }
}
